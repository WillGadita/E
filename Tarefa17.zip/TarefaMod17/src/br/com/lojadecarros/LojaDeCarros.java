package br.com.lojadecarros;

import java.util.ArrayList;
import java.util.List;

public class LojaDeCarros {

	public static void main(String[] args) {

		carrosFiat();
		carrosHonda();
		carrosChevrolet();
		
	}
	
	private static void carrosFiat() {
		List<String> lista = new ArrayList<>();
		lista.add("Fiat Toro");
		lista.add("Cor Verde");
		System.out.println(lista);
		
		
	}

	private static void carrosHonda() {
		List<String> lista1 = new ArrayList<>();
		lista1.add("Honda Civic");
		lista1.add("Cor Prata");
		System.out.println(lista1);
		
	}
	
	private static void carrosChevrolet() {
		List<String> lista2 = new ArrayList<>();
		lista2.add("Celta");
		lista2.add("Cor Branca");
		System.out.println(lista2);
}
}